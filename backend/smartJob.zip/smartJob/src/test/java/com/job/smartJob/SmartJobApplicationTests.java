package com.job.smartJob;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartJobApplicationTests {

	@Test
	void contextLoads() {
	}

}
